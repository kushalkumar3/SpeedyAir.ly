﻿// See https://aka.ms/new-console-template for more information
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SpeedyAir.ly.Core.Interfaces;
using SpeedyAir.ly.Infrastracture.Repositories;
using SpeedyAir.ly.Application.Services;
using SpeedyAir.ly.Application.Interfaces;
public class Program
{
    public static void Main(string[] args)
    {
        //setup our DI
        var serviceProvider = new ServiceCollection()
            .AddLogging()
            .AddSingleton<IOrderRepository, OrderRepository>()
            .AddSingleton<IOrderService, OrderService>()
            .AddSingleton<IFlightScheduleService, FlightScheduleService>()
            .AddSingleton<IFlightScheduleRepository, FlightScheduleRepository>()
            .AddSingleton<IScheduleOrderService, ScheduleOrderService>()
            .BuildServiceProvider();

        var _flightService = serviceProvider.GetService<IFlightScheduleService>();
        var _orderService = serviceProvider.GetService<IOrderService>();
        var _scheduleOrderService = serviceProvider.GetService<IScheduleOrderService>();

        //do the actual work here
        InitPortal.loadOrderSchedulePortal(_flightService, _orderService, _scheduleOrderService);
    }
}