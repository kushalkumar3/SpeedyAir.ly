// See https://aka.ms/new-console-template for more information
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SpeedyAir.ly.Core.Interfaces;
using SpeedyAir.ly.Infrastracture.Repositories;
using SpeedyAir.ly.Application.Services;
using SpeedyAir.ly.Application.Interfaces;
public class InitPortal
{  
    public static void loadOrderSchedulePortal(IFlightScheduleService _flightService,IOrderService _orderService, IScheduleOrderService _scheduleOrderService)
    {
        Console.WriteLine("Schedule orders portal!");
        Console.WriteLine("Press 1 to load flight schedule.");
        Console.WriteLine("Press 2 to list out loaded flight schedule.");
        Console.WriteLine("Press 3 to load and list out loaded orders.");
        int input = Console.Read();
        input = (int)char.GetNumericValue(Convert.ToChar(input));
        if (input == 1)
        {
            _flightService.LoadFlightSchedule("../Data/FlightSchedule.json");
        }
        else if (input == 2)
        {
            var flightSchedule = _flightService.GetFlightSchedule();
        }
        else if (input == 3)
        {
            var scheduleOrders = _scheduleOrderService.GetScheduleOrders(20);
        }
        loadOrderSchedulePortal(_flightService,_orderService,_scheduleOrderService);
        input = 0;
    }

}