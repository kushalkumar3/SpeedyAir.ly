using SpeedyAir.ly.Core.Entities;

namespace SpeedyAir.ly.Core.Interfaces
{
    public interface IOrderRepository
    {
        Task<List<Order>> GetOrders();        
    }
}
