using SpeedyAir.ly.Core.Entities;

namespace SpeedyAir.ly.Core.Interfaces
{
    public interface IOrderService
    {
        Task<List<Order>> GetOrders();  
    }
}
